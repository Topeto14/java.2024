public class ejercicioParaProbar {
    public static void main(String[] args) {
        
        //*20. Escriba usando variables las siguientes expresiones: */
        
        //1)
        
            // 5*(a*a)*(b*b*b)+Math.sqrt((a*a)+(b*b));

        //2)

            // Math.sqrt(4*a*(b*b))+ ((a+b)*(a+b))

        //3)

            // (((a*a*a)*b)/(2*a*b)) - Math.sqrt(12*(d*d*d*d));



    }
    
}
