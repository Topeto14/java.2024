public class ejercicio18Entregar {

    public static void main(String[] args) {
        
        //** 18. ¿Qué resultados se obtienen al realizar las operaciones siguientes? Si hay errores en la compilación, 
        //   corríjalos y dé una explicación de por qué suceden.
        int a = 10, b = 3 , e = 1, d;
        float x, y;
        x= a / b; 
        System.out.println("El resultado de x es " + x); //El resultado que se obtiene es el 3.0
       
        c = a < b && c; // Aqui hay error al compilar ya que no tenemos el valor de c
        d = a + b++;  // El resultado daria 13
        e = ++a – b;    // El resultado daria 8 
        y = (float)a / b; // El resultado es 3.3333333



    }
    
}
