public class ejercicioEntregar19 {

    public static void main(String[] args) {
        

        char J = 'J';
        int ASCII = (int) J;
        System.out.println("El valor ASCII de " + J + " es: " + ASCII); // J MAYUSUCLA = 74 

        char j = 'j';
        int ascii = (int) j;
        System.out.println("El valor ASCII de la letra 'j' minúscula es: " + ascii); // j minuscula = 106 

    }
    
}
